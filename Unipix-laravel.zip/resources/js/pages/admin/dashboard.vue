<template>
  <div></div>
</template>

<script>
export default {
  name: "dashboard"
}
</script>

<style scoped>

</style>