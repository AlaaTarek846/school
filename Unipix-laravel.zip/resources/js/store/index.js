import { createStore } from 'vuex';
import lang from './modules/language.js'

const store = createStore({
    state () {
        return {
        }
    },
    getters:{
    },
    mutations: {
    },
    actions:{

    },
    modules: {
        lang
    }
});

export default store;
