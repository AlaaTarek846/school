<!-- Footer Start -->
<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">


        <span class="text-muted"> Copyright 2025

                     by <a href="https://innovations-eg.com" target="_blank">

                        <span class="fw-semibold text-primary text-decoration-underline">Innovation</span>

                    </a>
                </span>
    </div>
</footer>
<!-- Footer End -->
