<!-- Jquery JS -->
{{--<script src="{{asset('dashboard/js/jquery.js')}}"></script>--}}

<!-- Popper JS -->
<script src="{{asset('dashboard/libs/@popperjs/core/umd/popper.min.js')}}"></script>

<!-- Popper JS -->
<script src="{{asset('dashboard/libs/@popperjs/core/umd/popper.min.js')}}"></script>

<!-- Bootstrap JS -->
<script src="{{asset('dashboard/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<!-- Defaultmenu JS -->
<script src="{{asset('dashboard/js/defaultmenu.min.js')}}"></script>

<!-- Show Password JS -->
<script src="{{asset('dashboard/js/show-password.js')}}"></script>

<!-- Node Waves JS-->
<script src="{{asset('dashboard/libs/node-waves/waves.min.js')}}"></script>

<!-- Color Picker JS -->
<script src="{{asset('dashboard/libs/@simonwep/pickr/pickr.es5.min.js')}}"></script>

<!-- JSVector Maps JS -->
<script src="{{asset('dashboard/libs/jsvectormap/js/jsvectormap.min.js')}}"></script>

<!-- JSVector Maps MapsJS -->
<script src="{{asset('dashboard/libs/jsvectormap/maps/world-merc.js')}}"></script>

<!-- Apex Charts JS -->
<script src="{{asset('dashboard/libs/apexcharts/apexcharts.min.js')}}"></script>

<!-- Chartjs Chart JS -->
<script src="{{asset('dashboard/libs/chart.js/chart.min.js')}}"></script>

<!-- Simplebar JS -->
<script src="{{asset('dashboard/libs/simplebar/simplebar.min.js')}}"></script>

<!-- Modal JS -->
{{--<script src="{{asset('dashboard/js/modal.js')}}"></script>--}}

<!-- Sweetalerts JS -->
<script src="{{asset('dashboard/libs/sweetalert2/sweetalert2.min.js')}}"></script>

<!-- Date & Time Picker JS -->
<script src="{{asset('dashboard/libs/flatpickr/flatpickr.min.js')}}"></script>
<script src="{{asset('dashboard/js/date&time_pickers.js')}}"></script>

<!-- Custom-Switcher JS -->
<script src="{{asset('dashboard/js/custom-switcher.min.js')}}"></script>

<!-- Custom JS -->
<script src="{{asset('dashboard/js/custom.js')}}"></script>

<!-- Prism JS -->
<script src="{{asset('dashboard/libs/prismjs/prism.js')}}"></script>
<script src="{{asset('dashboard/js/prism-custom.js')}}"></script>
<script src="/dashboard/js/vanillatoasts.js"></script>