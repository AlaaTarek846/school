<?php

return [
    'main' => 'Main',
];
