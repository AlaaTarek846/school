<?php

return [
    'gallery' => 'Gallery',
    'video' => 'Video',
    'link' => 'Link',
    'image' => 'Image',
    'actions' => 'Actions',
    'add' => 'Add',
    'save' => 'Save',
    'close' => 'Close',
    'update' => 'Update',
    'AreYouSure' => 'Are you sure?',
    'YouWontBeAbleToRevertThis' => 'You won\'t be able to revert this!',
    'YesDeleteIt' => 'Yes, delete it!',
    'Deleted' => 'Deleted!',
    'YourFileHasBeenDeleted' => 'Your file has been deleted.',
    'success' => 'Success',
    'AddedSuccessfully' => 'Added Successfully',
    'UpdatedSuccessfully' => 'Updated Successfully',
    'NoDataFound' => 'No Data Found',
];
