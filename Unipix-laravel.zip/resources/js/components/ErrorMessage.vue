<template>
    <div class="text-danger">
        <slot />
    </div>
</template>

<script>
export default {
    name: "errorMessage"
}
</script>

<style scoped>

</style>
