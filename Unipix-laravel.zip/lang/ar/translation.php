<?php

return [
    'main' => 'الرئيسية',
];
